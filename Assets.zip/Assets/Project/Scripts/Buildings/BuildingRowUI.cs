using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Controla la fila de UI de un edificio:
/// - Muestra nombre, nivel y coste
/// - Gestiona el botón de compra
/// - Respeta los requisitos de desbloqueo (gating suave)
/// </summary>
public class BuildingRowUI : MonoBehaviour
{
    [Header("Referencias UI")]
    public TextMeshProUGUI nameText;
    public TextMeshProUGUI levelText;
    public TextMeshProUGUI costText;
    public Button buyButton;
    public TextMeshProUGUI statsText;
    public Image tickFill;



    [Header("Estado visual")]
    [Tooltip("CanvasGroup de la fila, para manejar opacidad e interacción cuando está bloqueada.")]
    public CanvasGroup rowCanvasGroup;

    [Header("Rendimiento")]
    [SerializeField] private float refreshInterval = 0.25f;
    private float _t;

    // Estado del edificio que esta fila representa
    private BuildingState state;

    // Referencia al GameState para leer y gastar LE
    private GameState gameState;

    // Cache (para no re-asignar texto si no cambió)
    private bool _lastUnlocked;
    private int _lastLevel = -1;
    private double _lastCost = double.NaN;
    private string _lastReqText;
    private int _lastReqLang = -999;
    private string _cachedReqText = null;


    // Cache de nombre (no cambia)
    private string _cachedName;

    // Cache stats (para no recalcular / reescribir si no cambió)
    private int _lastLang = -999;

    private double _lastStatsLeTick = double.NaN;
    private double _lastStatsEmTick = double.NaN;
    private double _lastStatsIpTick = double.NaN;
    private double _lastStatsInterval = double.NaN;
    private double _lastStatsWorld = double.NaN;
    private int _lastStatsLang = -999;


    private string GetLocalizedBuildingName()
    {
        if (state == null || state.def == null) return "";

        string fallback = state.def.displayName ?? "";
        string key = $"bld.{state.def.id}.name";

        var lm = LocalizationManager.I;
        if (lm == null) return fallback;

        string s = lm.T(key);

        // Si no existe, tu T() devuelve la misma key
        if (string.IsNullOrEmpty(s) || s == key) return fallback;

        return s;
    }


    /// <summary>
    /// Inicializa la fila con un estado concreto y el GameState.
    /// La llamaremos desde el script que genere la lista.
    /// </summary>
    public void Init(BuildingState state, GameState gameState)
    {
        this.state = state;
        this.gameState = gameState;

        _cachedName = GetLocalizedBuildingName();

        if (buyButton != null)
        {
            buyButton.onClick.RemoveListener(OnBuyClicked);
            buyButton.onClick.AddListener(OnBuyClicked);
        }

        // Forzar primer refresh
        _lastUnlocked = true;
        _lastLevel = -1;
        _lastCost = double.NaN;
        _lastReqText = null;
        _lastStatsLeTick = double.NaN;
        _lastStatsEmTick = double.NaN;
        _lastStatsIpTick = double.NaN;
        _lastStatsInterval = double.NaN;
        _lastStatsWorld = double.NaN;


        Refresh();
    }

    private void Update()
    {

        UpdateTickBar();

        _t += Time.unscaledDeltaTime;
        if (_t < refreshInterval) return;
        _t = 0f;

        Refresh();
    }
    
    private void UpdateTickBar()
    {
        if (tickFill == null || state == null || state.def == null) return;

            bool unlocked = BuildingUnlock.IsUnlocked(state.def);


        // Ocultar si no produce todavía
        if (state.level <= 0 || state.def.tickInterval <= 0.0)
        {
            tickFill.transform.parent.gameObject.SetActive(false);
            return;
        }

        tickFill.transform.parent.gameObject.SetActive(true);

        float interval = (float)state.def.tickInterval;
        float p = Mathf.Clamp01((float)(state.tickTimer / interval));
        tickFill.fillAmount = p;


    }


    /// <summary>
    /// Actualiza los textos de la UI según el estado actual
    /// y si el edificio está desbloqueado o no.
    /// </summary>
    public void Refresh()
    {
        if (state == null || state.def == null || gameState == null)
            return;

        int langNow = (LocalizationManager.I != null) ? (int)LocalizationManager.I.CurrentLanguage : -1;
        bool langChanged = (langNow != _lastLang);
        if (langChanged) _lastLang = langNow;

        if (langChanged)
        _cachedName = GetLocalizedBuildingName();

        if (langChanged) _cachedReqText = null; // para que "Req:" se regenere en el nuevo idioma


        // Nombre siempre visible (no cambia normalmente)
        if (nameText != null && nameText.text != _cachedName)
            nameText.SetText(_cachedName);

        bool unlocked = BuildingUnlock.IsUnlocked(state.def);

        // Si cambió el estado bloqueado/desbloqueado, ajusta visual una sola vez
        if (unlocked != _lastUnlocked)
        {
            _lastUnlocked = unlocked;

            if (!unlocked)
            {
                // ---------- MODO BLOQUEADO ----------
                if (rowCanvasGroup != null)
                {
                    rowCanvasGroup.alpha = 0.4f;
                    rowCanvasGroup.interactable = false;
                    rowCanvasGroup.blocksRaycasts = false;
                }

                if (buyButton != null)
                    buyButton.interactable = false;

                if (levelText != null)
                    {
                        levelText.SetText(LocalizationManager.I != null
                            ? LocalizationManager.I.T("ui.locked")
                            : "Locked");
                    }


                // Requisitos
                _lastReqText = BuildRequirementsText(state.def);
                if (costText != null)
                    costText.SetText(_lastReqText);
                
                if (statsText != null) statsText.gameObject.SetActive(false);


                return; // ya está todo para modo bloqueado
            }
            else
            {
                // ---------- MODO DESBLOQUEADO ----------
                if (rowCanvasGroup != null)
                {
                    rowCanvasGroup.alpha = 1f;
                    rowCanvasGroup.interactable = true;
                    rowCanvasGroup.blocksRaycasts = true;
                }
            }
        }

        if (!unlocked)
        {

            // Los requisitos NO cambian con el tiempo, solo con idioma (y ni eso todavía)
            if (_cachedReqText == null)
            {
                _cachedReqText = BuildRequirementsText(state.def);

                if (costText != null)
                    costText.SetText(_cachedReqText);
            }


            if (statsText != null) statsText.gameObject.SetActive(false);


            return;
        }

        // ---------- MODO DESBLOQUEADO ----------
        // Botón activo si puede pagar (esto sí cambia seguido)
        bool canAfford = state.CanAfford(gameState.LE);
        if (buyButton != null)
            buyButton.interactable = canAfford;


        // Nivel (solo si cambió)
        // Nivel (actualiza si cambió el nivel o el idioma)
        if (state.level != _lastLevel || langChanged)
        {
            _lastLevel = state.level;

            if (levelText != null)
            {
                string lvl = (LocalizationManager.I != null)
                    ? LocalizationManager.I.T("ui.level_prefix")
                    : "Level:";

                levelText.SetText($"{lvl} {_lastLevel}");

            }
        }




        // Coste (solo si cambió)
        // Coste (actualiza si cambió el coste O cambió el idioma)
        if (!NearlyEqual(state.currentCost, _lastCost) || langChanged)
            {
                _lastCost = state.currentCost;

                if (costText != null)
                {
                    string costPrefix = (LocalizationManager.I != null)
                        ? LocalizationManager.I.T("ui.cost_prefix")
                        : "Cost:";

                    costText.SetText($"{costPrefix} {(float)_lastCost:0} LE");
                }
            }



        
        UpdateStatsText();
        UpdateTickBar();


    }

    private static bool NearlyEqual(double a, double b)
    {
        if (double.IsNaN(a) || double.IsNaN(b)) return false;
        return System.Math.Abs(a - b) < 0.0001;
    }

    private string L(string key, string fallback)
    {
        var lm = LocalizationManager.I;
        if (lm == null) return fallback;
        var s = lm.T(key);
        return string.IsNullOrEmpty(s) ? fallback : s;
    }

    private string LF(string key, string fallback, params object[] args)
    {
        string fmt = L(key, fallback);
        try { return string.Format(fmt, args); }
        catch { return fmt; }
    }



    private void UpdateStatsText()
{
    if (statsText == null || state == null || state.def == null || gameState == null)
        return;

    var def = state.def;

    if (def.tickInterval <= 0.0)
    {
        statsText.gameObject.SetActive(false);
        return;
    }

    statsText.gameObject.SetActive(true);

    double interval = def.tickInterval;
    double devMult = (TickSystem.I != null) ? TickSystem.I.devMultiplier : 1.0;
    double shownInterval = interval / devMult;

    double achFactor = (AchievementManager.I != null)
        ? AchievementManager.I.GetGlobalLEFactor()
        : 1.0;

    double worldMult = (1.0 + gameState.emMult) * gameState.researchGlobalLEMult * achFactor;

    double baseLeTick = def.lePerTickBase * state.level;
    double leTickReal = baseLeTick * worldMult;

    double emTick = 0.0;
    double ipTick = 0.0;

    if (def.emPerTickBase > 0.0)
    {
        double emGenFactor = 1.0;
        if (ResearchManager.I != null)
            emGenFactor *= ResearchManager.I.GetEMGenerationFactor();

        emGenFactor *= gameState.GetMetaEMGenerationMultiplier();

        emTick = def.emPerTickBase * state.level * emGenFactor;
        ipTick = emTick * 0.1;
    }

    int langNow = (LocalizationManager.I != null) ? (int)LocalizationManager.I.CurrentLanguage : -1;

    if (NearlyEqual(interval, _lastStatsInterval) &&
        NearlyEqual(leTickReal, _lastStatsLeTick) &&
        NearlyEqual(emTick, _lastStatsEmTick) &&
        NearlyEqual(ipTick, _lastStatsIpTick) &&
        NearlyEqual(worldMult, _lastStatsWorld) &&
        langNow == _lastStatsLang)
    {
        return;
    }

    _lastStatsInterval = interval;
    _lastStatsLeTick = leTickReal;
    _lastStatsEmTick = emTick;
    _lastStatsIpTick = ipTick;
    _lastStatsWorld = worldMult;
    _lastStatsLang = langNow;

    if (def.emPerTickBase > 0.0)
    {
        statsText.SetText(
            LF("ui.tick_basic_emip",
            "Tick: +{0:0.00} LE / {1:0.0}s\n+{2:0.00} EM  +{3:0.00} IP",
            (float)leTickReal, (float)shownInterval, (float)emTick, (float)ipTick)
        );
    }
    else
    {
        statsText.SetText(
            LF("ui.tick_basic",
            "Tick: +{0:0.00} LE / {1:0.0}s",
            (float)leTickReal, (float)shownInterval)
        );
    }
}
    


    /// <summary>
    /// Construye un texto corto de requisitos para que quepa mejor en la UI.
    /// Ejemplo: "Req: LE ≥ 5000 · Obs. ≥ 8"
    /// </summary>
    private string BuildRequirementsText(BuildingDef def)
    {
        // Prefijos localizados
        string prefix = (LocalizationManager.I != null)
            ? LocalizationManager.I.T("ui.req_prefix")
            : "Req:";

        string progress = (LocalizationManager.I != null)
            ? LocalizationManager.I.T("ui.req_progress")
            : "progress";

        string leLabel = (LocalizationManager.I != null) ? LocalizationManager.I.T("ui.req_le_label") : "LE";
        string ge      = (LocalizationManager.I != null) ? LocalizationManager.I.T("ui.req_ge") : "≥";
        string sep     = (LocalizationManager.I != null) ? LocalizationManager.I.T("ui.req_sep") : " · ";


        // Asegurar espacio después del prefijo
        if (!prefix.EndsWith(" ")) prefix += " ";

        bool hasAny = false;
        string s = prefix;

        if (def.unlockMinLE > 0.0)
        {
            hasAny = true;
            s += leLabel + " " + ge + " " + def.unlockMinLE.ToString("0");
        }

        if (!string.IsNullOrEmpty(def.unlockRequireId) && def.unlockRequireLevel > 0)
        {
            string shortName = GetShortReqName(def.unlockRequireId);
            if (hasAny) s += sep;
            hasAny = true;
            s += shortName + " " + ge + " " + def.unlockRequireLevel;
        }


        if (!hasAny)
            return prefix + progress;

        return s;
    }


    private string GetShortReqName(string id)
    {
        switch (id)
        {
            case "vacuum_observer":     return "Obs.";
            case "fluctuation_antenna": return "Ant.";
            case "decoherence_lab":     return "Lab";
            case "vacuum_amplifier":    return "Amp.";
            default:                    return id;
        }
    }

    private void OnBuyClicked()
    {
        if (state == null || gameState == null) return;

        // Por seguridad, no dejar comprar si aún está bloqueado
        if (!BuildingUnlock.IsUnlocked(state.def))
            return;

        // ¿Puede pagar?
        if (!state.CanAfford(gameState.LE))
            return;

        // Pagar coste
        gameState.LE -= state.currentCost;

        // Subir nivel y recalcular coste
        state.OnPurchased();

        // Forzar refresh de nivel/coste
        _lastLevel = -1;
        _lastCost = double.NaN;
        _lastStatsLeTick = double.NaN;
        _lastStatsEmTick = double.NaN;
        _lastStatsIpTick = double.NaN;
        _lastStatsInterval = double.NaN;
        _lastStatsWorld = double.NaN;


        Refresh();
    }
}
