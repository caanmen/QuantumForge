using System;

[Serializable]
public class SavedBuildingLevel
{
    public string id;
    public int level;
}
